
import React from 'react';

const Checkout = () => {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Checkout</h2>
      <p>Payment gateway integration goes here (e.g., Stripe).</p>
    </div>
  );
};

export default Checkout;
